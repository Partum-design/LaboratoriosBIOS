// TODO: Implementar página login del portal empresa B2B
export default function Page() {
  return <main><h1>Empresa — login</h1></main>;
}
