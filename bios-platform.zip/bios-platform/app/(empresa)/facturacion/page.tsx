// TODO: Implementar página facturacion del portal empresa B2B
export default function Page() {
  return <main><h1>Empresa — facturacion</h1></main>;
}
