// TODO: Semana 5 — Implementar FolioTracker
export default function FolioTracker() {
  return <div>FolioTracker</div>;
}
