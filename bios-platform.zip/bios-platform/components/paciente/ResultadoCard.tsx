// TODO: Semana 5 — Implementar ResultadoCard
export default function ResultadoCard() {
  return <div>ResultadoCard</div>;
}
