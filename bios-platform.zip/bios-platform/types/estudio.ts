export type EstatusEstudio =
  | "recibido"
  | "en_proceso"
  | "listo"
  | "entregado";

export interface Estudio {
  id: string;
  folio: string;
  pacienteId: string;
  tipo: string;
  estatus: EstatusEstudio;
  area: string; // quimica, imagen, patologia
  createdAt: string;
  entregadoEn?: string;
}
