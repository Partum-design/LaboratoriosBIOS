-- Tabla de facturas CFDI
create table if not exists facturas (
  id          uuid primary key default gen_random_uuid(),
  uuid_cfdi   text unique,
  empresa_id  uuid references empresas(id),
  total       numeric(10,2) not null,
  estatus     text not null default 'pendiente',
  xml_url     text,
  pdf_url     text,
  created_at  timestamptz default now()
);

alter table facturas enable row level security;
