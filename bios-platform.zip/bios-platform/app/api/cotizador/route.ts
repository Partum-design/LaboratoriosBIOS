import { NextResponse } from "next/server";

// TODO: Implementar API route — cotizador
export async function POST() {
  return NextResponse.json({ message: "ok" });
}

export async function GET() {
  return NextResponse.json({ message: "ok" });
}
