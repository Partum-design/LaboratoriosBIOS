// TODO: Implementar página empleados del portal empresa B2B
export default function Page() {
  return <main><h1>Empresa — empleados</h1></main>;
}
