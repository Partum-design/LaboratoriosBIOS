// TODO: Semana 3 — Implementar PopupDescuento
export default function PopupDescuento() {
  return <div>PopupDescuento</div>;
}
