// TODO: Semana 8 — Implementar PanelTrazabilidad
export default function PanelTrazabilidad() {
  return <div>PanelTrazabilidad</div>;
}
