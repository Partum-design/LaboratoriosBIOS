// TODO: Semana 7 — WhatsApp Cloud API (Meta)
// Docs: https://developers.facebook.com/docs/whatsapp/cloud-api

export async function enviarResultado(_telefono: string, _urlResultado: string) {
  // TODO: implementar envío de mensaje con link a resultado
  throw new Error("No implementado aún");
}

export async function enviarNotificacion(_telefono: string, _mensaje: string) {
  // TODO: implementar envío de notificación general
  throw new Error("No implementado aún");
}
