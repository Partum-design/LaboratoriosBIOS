// TODO: Semana 3 — implementar página servicios
export default function Page() {
  return (
    <main>
      <h1>servicios</h1>
    </main>
  );
}
