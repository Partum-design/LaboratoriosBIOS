-- Datos de prueba para desarrollo
-- Ejecutar solo en entorno local / staging, NUNCA en producción

insert into pacientes (folio, nombre, apellidos, telefono, correo)
values
  ('BIOS-0001', 'Juan', 'García López', '5512345678', 'juan@ejemplo.com'),
  ('BIOS-0002', 'María', 'Martínez Ruiz', '5598765432', 'maria@ejemplo.com');
