// TODO: Semana 3 — implementar página cotizador
export default function Page() {
  return (
    <main>
      <h1>cotizador</h1>
    </main>
  );
}
