// TODO: Semana 4 — Implementar CotizacionPDF
export default function CotizacionPDF() {
  return <div>CotizacionPDF</div>;
}
