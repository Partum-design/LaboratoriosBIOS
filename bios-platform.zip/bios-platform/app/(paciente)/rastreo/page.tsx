// TODO: Implementar página rastreo del portal paciente
export default function Page() {
  return <main><h1>Paciente — rastreo</h1></main>;
}
