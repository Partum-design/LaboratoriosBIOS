// TODO: Semana 3 — Implementar WhatsAppButton
export default function WhatsAppButton() {
  return <div>WhatsAppButton</div>;
}
