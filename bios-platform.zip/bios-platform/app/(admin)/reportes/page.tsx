// TODO: Implementar página reportes del panel de administración
export default function Page() {
  return <main><h1>Admin — reportes</h1></main>;
}
