export type TipoEmpresa = "fisica" | "moral";

export interface Empresa {
  id: string;
  rfc: string;
  nombre: string;
  tipo: TipoEmpresa;
  correo: string;
  telefono: string;
  createdAt: string;
}

export interface Empleado {
  id: string;
  empresaId: string;
  nombre: string;
  apellidos: string;
  curp?: string;
}
