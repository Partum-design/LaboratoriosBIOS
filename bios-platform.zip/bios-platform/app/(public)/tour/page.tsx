// TODO: Semana 3 — implementar página tour
export default function Page() {
  return (
    <main>
      <h1>tour</h1>
    </main>
  );
}
