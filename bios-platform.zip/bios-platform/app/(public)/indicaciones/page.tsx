// TODO: Semana 3 — implementar página indicaciones
export default function Page() {
  return (
    <main>
      <h1>indicaciones</h1>
    </main>
  );
}
