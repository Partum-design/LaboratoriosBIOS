// TODO: Semana 4 — Generación de PDFs con @react-pdf/renderer
// Usado para: cotizaciones, resultados descargables

export async function generarCotizacionPDF(_datos: object): Promise<Buffer> {
  // TODO: implementar template de cotización en PDF
  throw new Error("No implementado aún");
}
