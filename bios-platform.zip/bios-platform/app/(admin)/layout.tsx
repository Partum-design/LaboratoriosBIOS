// TODO: Auth guard — redirige a login si no hay sesión activa
export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
