// TODO: Semana 3 — Implementar CuponQR
export default function CuponQR() {
  return <div>CuponQR</div>;
}
