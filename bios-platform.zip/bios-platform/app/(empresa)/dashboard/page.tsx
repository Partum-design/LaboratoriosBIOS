// TODO: Implementar página dashboard del portal empresa B2B
export default function Page() {
  return <main><h1>Empresa — dashboard</h1></main>;
}
