// TODO: Semana 6 — Implementar FacturacionForm
export default function FacturacionForm() {
  return <div>FacturacionForm</div>;
}
