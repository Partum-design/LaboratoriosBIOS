// TODO: Semana 3 — implementar página diagnostico
export default function Page() {
  return (
    <main>
      <h1>diagnostico</h1>
    </main>
  );
}
