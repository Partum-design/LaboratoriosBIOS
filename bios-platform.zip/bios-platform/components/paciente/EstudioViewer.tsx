// TODO: Semana 5 — Implementar EstudioViewer
export default function EstudioViewer() {
  return <div>EstudioViewer</div>;
}
