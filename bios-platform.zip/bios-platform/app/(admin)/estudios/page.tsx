// TODO: Implementar página estudios del panel de administración
export default function Page() {
  return <main><h1>Admin — estudios</h1></main>;
}
