// TODO: Visualización de resultado individual (USG, RX, laboratorio)
export default function Page({ params }: { params: { id: string } }) {
  return <main><h1>Resultado #{params.id}</h1></main>;
}
