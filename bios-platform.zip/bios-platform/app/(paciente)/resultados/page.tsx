// TODO: Lista de resultados del paciente
export default function Page() {
  return <main><h1>Mis resultados</h1></main>;
}
