// TODO: Semana 2 — Implementar Sidebar
export default function Sidebar() {
  return <div>Sidebar</div>;
}
