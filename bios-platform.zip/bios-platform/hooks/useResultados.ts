"use client";
// TODO: Semana 5 — Hook para obtener resultados del paciente desde Supabase
export function useResultados(_pacienteId: string) {
  return { resultados: [], loading: false, error: null };
}
