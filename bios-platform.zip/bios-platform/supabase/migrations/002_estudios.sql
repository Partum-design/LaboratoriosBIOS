-- Tabla de estudios / resultados
create table if not exists estudios (
  id           uuid primary key default gen_random_uuid(),
  folio        text unique not null,
  paciente_id  uuid references pacientes(id),
  tipo         text not null, -- laboratorio, ultrasonido, radiografia
  estatus      text not null default 'recibido',
  area         text,
  archivo_url  text,
  expira_en    timestamptz, -- 30 días desde entrega
  created_at   timestamptz default now(),
  entregado_en timestamptz
);

alter table estudios enable row level security;

create policy "Paciente ve sus estudios"
  on estudios for select
  using (paciente_id in (
    select id from pacientes where auth.uid()::text = id::text
  ));
