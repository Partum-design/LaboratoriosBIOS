// TODO: Semana 3 — implementar página empleos
export default function Page() {
  return (
    <main>
      <h1>empleos</h1>
    </main>
  );
}
