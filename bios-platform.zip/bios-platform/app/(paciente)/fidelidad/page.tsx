// TODO: Implementar página fidelidad del portal paciente
export default function Page() {
  return <main><h1>Paciente — fidelidad</h1></main>;
}
