// TODO: Semana 3 — implementar página Home
export default function Page() {
  return (
    <main>
      <h1>Home</h1>
    </main>
  );
}
