// TODO: Semana 6 — Implementar EmpleadosTable
export default function EmpleadosTable() {
  return <div>EmpleadosTable</div>;
}
