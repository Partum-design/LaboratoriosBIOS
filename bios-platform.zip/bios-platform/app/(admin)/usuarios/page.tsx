// TODO: Implementar página usuarios del panel de administración
export default function Page() {
  return <main><h1>Admin — usuarios</h1></main>;
}
