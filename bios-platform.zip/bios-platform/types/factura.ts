export interface Factura {
  id: string;
  uuid: string; // UUID del CFDI
  empresaId: string;
  total: number;
  estatus: "pendiente" | "timbrada" | "cancelada";
  xmlUrl?: string;
  pdfUrl?: string;
  createdAt: string;
}
