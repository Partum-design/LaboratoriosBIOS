-- Tabla de empresas B2B
create table if not exists empresas (
  id         uuid primary key default gen_random_uuid(),
  rfc        text unique not null,
  nombre     text not null,
  tipo       text not null default 'moral', -- fisica | moral
  correo     text,
  telefono   text,
  created_at timestamptz default now()
);

-- Tabla de empleados de empresa
create table if not exists empleados (
  id          uuid primary key default gen_random_uuid(),
  empresa_id  uuid references empresas(id),
  nombre      text not null,
  apellidos   text not null,
  curp        text,
  created_at  timestamptz default now()
);

alter table empresas  enable row level security;
alter table empleados enable row level security;
