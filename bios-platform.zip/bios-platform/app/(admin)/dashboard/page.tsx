// TODO: Implementar página dashboard del panel de administración
export default function Page() {
  return <main><h1>Admin — dashboard</h1></main>;
}
