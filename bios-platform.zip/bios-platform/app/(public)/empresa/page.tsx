// TODO: Semana 3 — implementar página empresa
export default function Page() {
  return (
    <main>
      <h1>empresa</h1>
    </main>
  );
}
