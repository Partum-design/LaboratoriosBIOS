import { type NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";

export async function middleware(request: NextRequest) {
  return await updateSession(request);
}

export const config = {
  matcher: [
    // Protege portales de paciente, empresa y admin
    "/dashboard/:path*",
    "/resultados/:path*",
    "/rastreo/:path*",
    "/fidelidad/:path*",
    "/empresa/dashboard/:path*",
    "/empresa/facturacion/:path*",
    "/empresa/empleados/:path*",
    "/empresa/reportes/:path*",
    "/admin/:path*",
  ],
};
