-- Tabla de pacientes
create table if not exists pacientes (
  id          uuid primary key default gen_random_uuid(),
  folio       text unique not null,
  nombre      text not null,
  apellidos   text not null,
  telefono    text,
  correo      text,
  created_at  timestamptz default now()
);

-- Row Level Security: cada paciente solo ve sus datos
alter table pacientes enable row level security;

create policy "Paciente ve sus propios datos"
  on pacientes for select
  using (auth.uid()::text = id::text);
