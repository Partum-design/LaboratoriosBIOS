// TODO: Semana 4 — Implementar CotizadorForm
export default function CotizadorForm() {
  return <div>CotizadorForm</div>;
}
