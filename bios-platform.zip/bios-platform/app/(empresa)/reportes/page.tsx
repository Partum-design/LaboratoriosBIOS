// TODO: Implementar página reportes del portal empresa B2B
export default function Page() {
  return <main><h1>Empresa — reportes</h1></main>;
}
