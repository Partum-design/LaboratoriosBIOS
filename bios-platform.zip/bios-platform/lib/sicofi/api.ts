// TODO: Semana 6 — Integración SICOFI para facturación CFDI
// Documentación: https://api.sicofi.com.mx/docs

export interface DatosFactura {
  rfcReceptor: string;
  nombreReceptor: string;
  usoCFDI: string;
  conceptos: Concepto[];
}

export interface Concepto {
  descripcion: string;
  cantidad: number;
  valorUnitario: number;
  claveProducto: string;
}

export async function generarCFDI(_datos: DatosFactura) {
  // TODO: implementar llamada a SICOFI API
  throw new Error("No implementado aún");
}
