// TODO: Semana 8 — Implementar ReportesTable
export default function ReportesTable() {
  return <div>ReportesTable</div>;
}
