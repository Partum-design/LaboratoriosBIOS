"use client";
// TODO: Semana 4 — Hook para la lógica del cotizador de paquetes
export function useCotizador() {
  return { total: 0, servicios: [], agregar: () => {}, limpiar: () => {} };
}
