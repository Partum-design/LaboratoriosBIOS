# Laboratorios BIOS — Plataforma Digital

Plataforma digital integral para Laboratorios BIOS: portal de pacientes, sistema de facturación CFDI, portal B2B, cotizador y más.

**Desarrollado por:** Partum Design  
**Período:** 05 Mayo – 05 Agosto 2026  
**Versión actual:** 0.1.0 (Semana 1 — Arquitectura base)

---

## Stack tecnológico

| Capa | Tecnología |
|------|-----------|
| Frontend | Next.js 15 + React 18 + TypeScript |
| Estilos | Tailwind CSS + shadcn/ui |
| Backend / BaaS | Supabase (PostgreSQL + Auth + Storage) |
| Facturación | SICOFI API (CFDI) |
| WhatsApp | Meta WhatsApp Cloud API |
| Email | Resend |
| PDF | @react-pdf/renderer |
| Hosting | Vercel |
| Dominio / CDN | Cloudflare |
| Analítica | Microsoft Clarity + Vercel Analytics |

---

## Requisitos

- Node.js 18.17 o superior
- Cuenta en [Supabase](https://supabase.com)
- Cuenta en [Vercel](https://vercel.com)

---

## Instalación

```bash
# 1. Clonar el repositorio
git clone https://github.com/tu-usuario/bios-platform.git
cd bios-platform

# 2. Instalar dependencias
npm install

# 3. Configurar variables de entorno
cp .env.example .env.local
# Editar .env.local con tus credenciales reales

# 4. Iniciar en desarrollo
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000) en tu navegador.

---

## Estructura del proyecto

```
bios-platform/
├── app/              # Next.js App Router (páginas y API routes)
│   ├── (public)/     # Rutas públicas: home, catálogo, cotizador
│   ├── (paciente)/   # Portal de pacientes (requiere auth)
│   ├── (empresa)/    # Portal B2B empresas (requiere auth)
│   ├── (admin)/      # Panel de administración (requiere auth)
│   └── api/          # API routes: SICOFI, WhatsApp, PDF, cupones
├── components/       # Componentes React reutilizables
├── lib/              # Servicios: Supabase, SICOFI, WhatsApp, PDF
├── hooks/            # Custom React hooks
├── types/            # Tipos TypeScript del dominio
├── supabase/         # Migraciones SQL y seed de datos
└── public/           # Assets estáticos
```

---

## Roadmap por semanas

| Semana | Objetivo |
|--------|----------|
| S1 | ✅ Arquitectura base, estructura, entorno |
| S2 | UI/UX — componentes, sistema visual |
| S3 | Frontend público: home, catálogo, WhatsApp |
| S4 | Cotizador + generación de PDFs |
| S5 | Portal paciente + carga de estudios |
| S6 | Facturación SICOFI + portal empresa |
| S7 | Indicaciones, diagnóstico, bolsa de trabajo, tour 360° |
| S8 | Analítica, mapas de calor, panel admin |
| S9-10 | QA, optimización, seguridad |
| S11 | Capacitación equipo BIOS |
| S12 | Lanzamiento oficial + soporte |

---

## Variables de entorno

Ver `.env.example` para la lista completa de variables necesarias.

---

*Partum Design · Laboratorios BIOS · Mayo 2026*
