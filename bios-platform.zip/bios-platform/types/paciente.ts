export interface Paciente {
  id: string;
  folio: string;
  nombre: string;
  apellidos: string;
  telefono: string;
  correo?: string;
  fechaNacimiento?: string;
  createdAt: string;
}

export interface Resultado {
  id: string;
  pacienteId: string;
  tipo: "laboratorio" | "ultrasonido" | "radiografia";
  descripcion: string;
  archivoUrl: string;
  expiraEn: string; // 30 días desde la fecha de entrega
  createdAt: string;
}
