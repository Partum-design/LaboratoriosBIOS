// TODO: Semana 2 — Implementar Header
export default function Header() {
  return <div>Header</div>;
}
