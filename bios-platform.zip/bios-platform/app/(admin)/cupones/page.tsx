// TODO: Implementar página cupones del panel de administración
export default function Page() {
  return <main><h1>Admin — cupones</h1></main>;
}
