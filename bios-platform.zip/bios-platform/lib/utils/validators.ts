// Validaciones específicas para México

export function validarRFC(rfc: string): boolean {
  const regex = /^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$/;
  return regex.test(rfc.toUpperCase());
}

export function validarTelefono(tel: string): boolean {
  const limpio = tel.replace(/\D/g, "");
  return limpio.length === 10;
}

export function validarFolio(folio: string): boolean {
  return folio.trim().length >= 4;
}
