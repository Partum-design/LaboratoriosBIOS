// TODO: Semana 2 — Implementar Footer
export default function Footer() {
  return <div>Footer</div>;
}
