// TODO: Implementar página login del portal paciente
export default function Page() {
  return <main><h1>Paciente — login</h1></main>;
}
