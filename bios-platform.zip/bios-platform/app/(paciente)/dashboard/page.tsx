// TODO: Implementar página dashboard del portal paciente
export default function Page() {
  return <main><h1>Paciente — dashboard</h1></main>;
}
